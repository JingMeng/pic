package com.darren.view_day31

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    // 十几台   三种 低（性能，分辨率）中高
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        red_pack_view.setTotalProgress(3);
        red_pack_view.setOnClickListener{
            red_pack_view.startAnimation(1,3);
        }
    }
}
