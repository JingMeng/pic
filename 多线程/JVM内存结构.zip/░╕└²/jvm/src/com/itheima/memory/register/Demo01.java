package com.itheima.memory.register;

import java.io.PrintStream;

public class Demo01 {
    public static void main(String[] args) {
        PrintStream out = System.out;
        out.println(1);
        out.println(2);
        out.println(3);
        out.println(4);
        out.println(5);
    }
}
