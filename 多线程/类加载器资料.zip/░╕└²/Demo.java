package com.itheima;
public class Demo{
	public Demo(){
		System.out.println("hello java");
	}
}