package java.lang;

public class MyObject {
}
