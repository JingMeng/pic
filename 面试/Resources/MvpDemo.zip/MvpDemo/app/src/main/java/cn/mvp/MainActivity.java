package cn.mvp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import cn.mvp.bean.User;
import cn.mvp.presenter.UserLoginPresenter;
import cn.mvp.retrofit.ApiServiceManager;
import cn.mvp.ui.UserLoginView;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity implements UserLoginView {
    private static final String TAG = "MainActivity";
    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnClear;
    private Button btnWeather;
    private Button btnNews;
    private Button btnMovie;
    private UserLoginPresenter mLoginPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etUsername = (EditText) findViewById(R.id.et_username);
        etPassword = (EditText) findViewById(R.id.et_password);
        btnLogin = (Button) findViewById(R.id.btn_login);
        btnClear = (Button) findViewById(R.id.btn_clear);
        mLoginPresenter = new UserLoginPresenter(this);


        findViewById(R.id.btn_test).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // FIXME: 2018/9/29 这个地方又废了
                String dataUrl = "https://api.github.com/";//users/list/
                ApiServiceManager.getData2(dataUrl).subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Subscriber<retrofit2.Response>() {
                            @Override
                            public void onCompleted() {

                            }

                            @Override
                            public void onError(Throwable e) {

                            }

                            @Override
                            public void onNext(retrofit2.Response response) {
                                Log.i(TAG, response.body().toString());
                                Log.i(TAG, response.raw().toString());
                            }
                        });

                if (true) {
                    return;
                }
                // FIXME: 2018/9/29  思考这个试验品
                ApiServiceManager.getDatas(dataUrl).enqueue(new Callback<Object>() {
                    @Override
                    public void onResponse(Call<Object> call, retrofit2.Response<Object> response) {
                        Object o = response.body();
                        try {
                            Response response2 = response.raw();
                            Log.i(TAG, o.toString());
                            Log.i(TAG, response2.toString());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(Call<Object> call, Throwable t) {

                    }
                });
                if (true) {
                    return;
                }
                //    java.lang.IllegalArgumentException: baseUrl must end in /: https://api.github.com/users/list
                //通过这个地址来的

                //  java.lang.IllegalArgumentException: 'okhttp3.Response' is not a valid response body type. Did you mean ResponseBody?
                ApiServiceManager.getData(dataUrl).subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<ResponseBody>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.i(TAG, Log.getStackTraceString(e));
                    }

                    @Override
                    public void onNext(ResponseBody response) {
                        try {
                            //{"login":"list","id":1133421,"node_id":"MDQ6VXNlcjExMzM0MjE=","avatar_url":"https://avatars3.githubusercontent.com/u/1133421?v=4","gravatar_id":"","url":"https://api.github.com/users/list","html_url":"https://github.com/list","followers_url":"https://api.github.com/users/list/followers","following_url":"https://api.github.com/users/list/following{/other_user}","gists_url":"https://api.github.com/users/list/gists{/gist_id}","starred_url":"https://api.github.com/users/list/starred{/owner}{/repo}","subscriptions_url":"https://api.github.com/users/list/subscriptions","organizations_url":"https://api.github.com/users/list/orgs","repos_url":"https://api.github.com/users/list/repos","events_url":"https://api.github.com/users/list/events{/privacy}","received_events_url":"https://api.github.com/users/list/received_events","type":"User","site_admin":false,"name":null,"company":null,"blog":"","location":null,"email":null,"hireable":null,"bio":null,"public_repos":1,"public_gists":3,"followers":0,"following":0,"created_at":"2011-10-17T14:53:35Z","updated_at":"2016-02-27T00:59:03Z"}
                            Log.i(TAG, new String(response.bytes()));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mLoginPresenter.login();
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RxJavaActivity.class);
                startActivity(intent);
            }
        });
        btnWeather = (Button) findViewById(R.id.btn_weather);
        btnWeather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, WeatherActivity.class);
                startActivity(intent);
            }
        });
        btnNews = (Button) findViewById(R.id.btn_news);
        btnNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewsActivity.class);
                startActivity(intent);
            }
        });
        btnMovie = (Button) findViewById(R.id.btn_movie);
        btnMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MovieActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public String getUserName() {
        return etUsername.getText().toString().trim();
    }

    @Override
    public String getPassword() {
        return etPassword.getText().toString().trim();
    }

    @Override
    public void clearUserName() {
        etUsername.setText("");
    }

    @Override
    public void clearPassword() {
        etPassword.setText("");
    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    @Override
    public void toMainActivity(User user) {
        Toast.makeText(this, "欢迎你!" + user.getUsername(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void showFailedError() {
        Toast.makeText(this, "登录失败", Toast.LENGTH_LONG).show();
    }
}
