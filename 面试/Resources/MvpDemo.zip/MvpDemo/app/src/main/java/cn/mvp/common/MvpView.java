package cn.mvp.common;

/**
 * <p>Title: cn.mvp.newmvp.common</p>
 * 所有view的基类接口
 *
 * @author : Huawen
 * @version 1.0
 * @date : 2016年12月27日 13:54
 * Description:
 */

public interface MvpView {
}
