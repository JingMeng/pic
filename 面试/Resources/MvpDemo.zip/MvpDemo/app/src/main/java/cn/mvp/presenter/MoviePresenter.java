package cn.mvp.presenter;

/**
 * <p>Title: cn.mvp.presenter</p>
 *
 * @author : Huawen
 * @version 1.0
 * @date : 2016年12月27日 15:01
 * Description:
 */

public interface MoviePresenter {
    /**
     * @param start
     * @param count
     */
    void getMovies(int start, int count);

}
