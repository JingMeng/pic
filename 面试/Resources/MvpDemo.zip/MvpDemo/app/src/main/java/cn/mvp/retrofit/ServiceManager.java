package cn.mvp.retrofit;

import retrofit2.Retrofit;

/**
 * <p>Title: cn.mvp.retrofit</p>
 *
 * @author : Huawen
 * @version 1.0
 * @date : 2016年12月27日 16:11
 * Description:
 */

public class ServiceManager {

    private static Retrofit sRetrofit;
    private String baseUrl;



}
